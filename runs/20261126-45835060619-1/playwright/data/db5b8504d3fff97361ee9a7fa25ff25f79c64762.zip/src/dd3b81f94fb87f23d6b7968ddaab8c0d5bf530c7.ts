import { test, expect, type Page } from '../support/test';
import { fixedTestUser, loginAs } from '../support/auth';
import { messagesFixture } from '../seed/messages';
import { E2E_SEATS_GV_ID } from '../seed/seats';

// The chats (`src/api/handlers/chat/`): a chat is read by its parties and, for a team chat, by
// whoever answers its inbox; participants know each other by role only; participant care reads a
// chat between participants only while a report is open; blocks, suspensions and the conference's
// switch close a chat between delegations for writing, while the team and the own delegation's
// group are reached from the registration on. The specs build on each other's chats, so they run in order
// (the fixture, e2e/seed/messages.ts, starts every run without any).
// Several people sign in per test, each through the provider once.
test.describe.configure({ mode: 'serial', timeout: 90_000 });

type GraphQLResult<T = Record<string, unknown>> = {
	data?: T | null;
	errors?: { message: string; extensions?: { code?: string } }[];
};

async function gql<T = Record<string, unknown>>(
	page: Page,
	query: string,
	variables: Record<string, unknown> = {}
) {
	const res = await page.request.post('/api/graphql', {
		headers: { 'x-locale': 'en' },
		data: { query, variables }
	});
	return (await res.json()) as GraphQLResult<T>;
}

const codeOf = (result: GraphQLResult) => result.errors?.[0]?.extensions?.code;

async function signedIn(browser: import('@playwright/test').Browser, id: string) {
	const page = await (await browser.newContext()).newPage();
	await loginAs(page, fixedTestUser(id, fixture.claims(id)));
	return page;
}

const fixture = messagesFixture('auth');
const CONFERENCE = fixture.conferenceId;
const GV = fixture.gvId;
const SR = fixture.srId;
const { anna, bert, carla, dora } = fixture.delegates;
const { care, chair, reviewer, management, member, tessa, theo } = fixture.team;
const participant = (person: { id: string }) => fixture.participantId(person.id);

const OPEN_DIRECT = `mutation ($c: ID!, $p: ID!) { openDirectChat(conferenceId: $c, participantId: $p) { id } }`;
const OPEN_TEAM = `mutation ($c: ID!, $inbox: ChatinboxEnum!, $committee: ID, $p: ID, $trusted: ID) {
	openTeamChat(
		conferenceId: $c, inbox: $inbox, committeeId: $committee, participantId: $p, trustedPersonId: $trusted
	) { id }
}`;
const OPEN_GROUP = `mutation ($c: ID!) { openDelegationChat(conferenceId: $c) { id } }`;
const SEND = `mutation ($chat: ID!, $body: String!) { sendChatMessage(chatId: $chat, body: $body) { id } }`;
const CHATS = `query ($c: ID!) {
	chats(where: { conferenceId: { eq: $c } }) {
		id kind side underReview
		contacts { participantId roleKind nationAlpha3Code committeeAbbreviation userId suspended }
		people { name userId earlierReports }
	}
}`;
const MESSAGES = `query ($chat: ID!) {
	chatMessages(where: { chatId: { eq: $chat } }, orderBy: { createdAt: asc }) {
		body mine fromTeam authorName authorParticipantId teamAuthorUserId
	}
}`;

type ChatRow = {
	id: string;
	kind: string;
	side: string;
	underReview: boolean;
	contacts: {
		participantId: string;
		nationAlpha3Code: string | null;
		committeeAbbreviation: string | null;
		userId: string | null;
		suspended: boolean | null;
	}[];
	people: { name: string; userId: string; earlierReports: number }[];
};
type MessageRow = {
	body: string;
	mine: boolean;
	fromTeam: boolean;
	authorName: string | null;
	authorParticipantId: string | null;
	teamAuthorUserId: string | null;
};

const TERMS = `query { messagingTerms { version revision contentHash confirmations { key } } }`;
const ACCEPT_TERMS = `mutation ($version: Int!, $revision: Int!, $contentHash: String!, $confirmationIds: [String!]!) {
	acceptMessagingTerms(version: $version, revision: $revision, contentHash: $contentHash, confirmationIds: $confirmationIds)
}`;
interface TermsRow {
	version: number;
	revision: number;
	contentHash: string;
	confirmations: { key: string }[];
}

const chatsOf = async (page: Page) =>
	(await gql<{ chats: ChatRow[] }>(page, CHATS, { c: CONFERENCE })).data?.chats ?? [];
const messagesOf = async (page: Page, chat: string) =>
	(await gql<{ chatMessages: MessageRow[] }>(page, MESSAGES, { chat })).data?.chatMessages ?? [];

async function openDirect(page: Page, to: { id: string }) {
	const result = await gql<{ openDirectChat: { id: string } }>(page, OPEN_DIRECT, {
		c: CONFERENCE,
		p: participant(to)
	});
	return { id: result.data?.openDirectChat?.id ?? '', result };
}

async function openTeam(
	page: Page,
	args: { inbox: string; committee?: string; p?: string; trusted?: string }
) {
	const result = await gql<{ openTeamChat: { id: string } }>(page, OPEN_TEAM, {
		c: CONFERENCE,
		...args
	});
	return { id: result.data?.openTeamChat?.id ?? '', result };
}

const send = (page: Page, chat: string, body: string) => gql(page, SEND, { chat, body });

/** The chats the specs below build up, by who they are between. */
const chat = { annaCarla: '', annaChairs: '', annaConsultants: '', bertCare: '' };

test('two delegates write each other and know each other by role only', async ({ browser }) => {
	const annaPage = await signedIn(browser, anna.id);
	const carlaPage = await signedIn(browser, carla.id);

	const contacts = await gql<{
		chatContacts: { participantId: string; nationAlpha3Code: string; userId: string | null }[];
	}>(
		annaPage,
		`query ($c: ID!) { chatContacts(conferenceId: $c) { participantId nationAlpha3Code userId } }`,
		{
			c: CONFERENCE
		}
	);
	const listed = contacts.data?.chatContacts ?? [];
	// everybody seated but herself, and nobody's account
	expect(listed.map((contact) => contact.participantId).sort()).toEqual(
		[bert, carla, dora].map(participant).sort()
	);
	expect(listed.every((contact) => contact.userId === null)).toBe(true);

	chat.annaCarla = (await openDirect(annaPage, carla)).id;
	expect(chat.annaCarla).not.toBe('');
	// the same two people share one chat, whoever opens it
	expect((await openDirect(carlaPage, anna)).id).toBe(chat.annaCarla);

	// a participant agrees to the terms of the message service before their first message, and to
	// the version they were shown
	expect(codeOf(await send(annaPage, chat.annaCarla, 'Hallo Frankreich!'))).toBe(
		'TERMS_NOT_ACCEPTED'
	);
	expect(await messagesOf(carlaPage, chat.annaCarla)).toEqual([]);
	const terms = (await gql<{ messagingTerms: TermsRow }>(annaPage, TERMS)).data?.messagingTerms;
	if (!terms) throw new Error('The terms of the message service did not load');
	const shown = {
		version: terms.version,
		revision: terms.revision,
		contentHash: terms.contentHash,
		confirmationIds: terms.confirmations.map((confirmation) => confirmation.key)
	};
	// another version, another text or a statement left unticked is no agreement
	for (const wrong of [
		{ ...shown, version: shown.version + 1 },
		{ ...shown, contentHash: 'not-what-she-was-shown' },
		{ ...shown, confirmationIds: shown.confirmationIds.slice(1) }
	]) {
		expect(codeOf(await gql(annaPage, ACCEPT_TERMS, wrong))).toBe('INVALID_INPUT');
	}
	expect(codeOf(await send(annaPage, chat.annaCarla, 'Hallo Frankreich!'))).toBe(
		'TERMS_NOT_ACCEPTED'
	);
	expect((await gql(annaPage, ACCEPT_TERMS, shown)).errors).toBeUndefined();

	expect((await send(annaPage, chat.annaCarla, 'Hallo Frankreich!')).errors).toBeUndefined();
	expect((await send(carlaPage, chat.annaCarla, 'Hallo Deutschland!')).errors).toBeUndefined();

	const carlasChat = (await chatsOf(carlaPage)).find((row) => row.id === chat.annaCarla);
	expect(carlasChat?.side).toBe('PARTICIPANT');
	expect(carlasChat?.contacts).toEqual([
		expect.objectContaining({
			participantId: participant(anna),
			nationAlpha3Code: 'deu',
			committeeAbbreviation: fixture.gv,
			userId: null,
			suspended: null
		})
	]);
	expect(carlasChat?.people).toEqual([]);

	const messages = await messagesOf(carlaPage, chat.annaCarla);
	expect(messages.map((message) => [message.body, message.mine])).toEqual([
		['Hallo Frankreich!', false],
		['Hallo Deutschland!', true]
	]);
	expect(messages.every((message) => message.authorName === null)).toBe(true);
	expect(messages.every((message) => message.teamAuthorUserId === null)).toBe(true);
});

test('nobody outside a direct chat reads it or writes in it', async ({ browser }) => {
	for (const outsider of [bert, care, chair, management, { id: fixture.supervisorId }]) {
		const page = await signedIn(browser, outsider.id);
		expect(
			(await chatsOf(page)).map((row) => row.id),
			outsider.id
		).not.toContain(chat.annaCarla);
		expect(await messagesOf(page, chat.annaCarla), outsider.id).toEqual([]);
		expect(codeOf(await send(page, chat.annaCarla, 'mitlesen')), outsider.id).toBe('NOT_FOUND');
	}
});

test('supervisors and team members without an inbox take no part', async ({ browser }) => {
	const supervisorPage = await signedIn(browser, fixture.supervisorId);
	expect(codeOf((await openDirect(supervisorPage, anna)).result)).toBe('FORBIDDEN');
	expect(codeOf((await openTeam(supervisorPage, { inbox: 'PARTICIPANT_CARE' })).result)).toBe(
		'FORBIDDEN'
	);

	const memberPage = await signedIn(browser, member.id);
	expect(
		codeOf(
			await gql(
				memberPage,
				`query ($c: ID!) { chatContacts(conferenceId: $c) { participantId } }`,
				{
					c: CONFERENCE
				}
			)
		)
	).toBe('FORBIDDEN');
	expect(
		codeOf((await openTeam(memberPage, { inbox: 'PARTICIPANT_CARE', p: participant(anna) })).result)
	).toBe('FORBIDDEN');
});

test('a team inbox is read by whoever answers it, and answers carry a name', async ({
	browser
}) => {
	const annaPage = await signedIn(browser, anna.id);
	const bertPage = await signedIn(browser, bert.id);
	const chairPage = await signedIn(browser, chair.id);
	const reviewerPage = await signedIn(browser, reviewer.id);
	const carePage = await signedIn(browser, care.id);

	// Anna sits in GV: its chairs and consultants are hers to write to, participant care and the
	// trusted persons anybody's
	const inboxes = await gql<{ chatInboxes: { inbox: string; committeeId: string | null }[] }>(
		annaPage,
		`query ($c: ID!) { chatInboxes(conferenceId: $c) { inbox committeeId } }`,
		{ c: CONFERENCE }
	);
	expect(inboxes.data?.chatInboxes).toEqual([
		{ inbox: 'PARTICIPANT_CARE', committeeId: null },
		// the trusted persons together, and each of the two
		{ inbox: 'TRUSTED_PERSON', committeeId: null },
		{ inbox: 'TRUSTED_PERSON', committeeId: null },
		{ inbox: 'TRUSTED_PERSON', committeeId: null },
		{ inbox: 'CHAIR', committeeId: GV },
		{ inbox: 'CONSULTANT', committeeId: GV }
	]);

	chat.annaChairs = (await openTeam(annaPage, { inbox: 'CHAIR', committee: GV })).id;
	chat.annaConsultants = (await openTeam(annaPage, { inbox: 'CONSULTANT', committee: GV })).id;
	chat.bertCare = (await openTeam(bertPage, { inbox: 'PARTICIPANT_CARE' })).id;
	await send(annaPage, chat.annaChairs, 'Frage an den Vorsitz');
	await send(annaPage, chat.annaConsultants, 'Frage an die Beratung');
	await send(bertPage, chat.bertCare, 'Frage an die Betreuung');

	// Bert sits in SR, which nobody chairs: GV's chairs are not his
	expect(codeOf((await openTeam(bertPage, { inbox: 'CHAIR', committee: GV })).result)).toBe(
		'CONFLICT'
	);

	const idsOf = async (page: Page) => (await chatsOf(page)).map((row) => row.id).sort();
	expect(await idsOf(chairPage)).toEqual([chat.annaChairs]);
	expect(await idsOf(reviewerPage)).toEqual([chat.annaConsultants]);
	expect(await idsOf(carePage)).toEqual([chat.bertCare]);

	// the chair answers; Anna reads who of the team wrote, the chair reads her by role
	expect((await send(chairPage, chat.annaChairs, 'Antwort vom Vorsitz')).errors).toBeUndefined();
	const [, answer] = await messagesOf(annaPage, chat.annaChairs);
	expect(answer).toMatchObject({
		body: 'Antwort vom Vorsitz',
		fromTeam: true,
		mine: false,
		authorName: `${chair.given} ${chair.family}`,
		teamAuthorUserId: null
	});
	const [chairsChat] = await chatsOf(chairPage);
	expect(chairsChat?.side).toBe('TEAM');
	expect(chairsChat?.contacts[0]).toMatchObject({ nationAlpha3Code: 'deu', userId: null });
	expect(chairsChat?.people).toEqual([]);
	const [question] = await messagesOf(chairPage, chat.annaChairs);
	expect(question?.authorName).toBeNull();

	// participant care knows whom it is talking to
	const [caresChat] = await chatsOf(carePage);
	expect(caresChat?.people).toEqual([
		{ name: `${bert.given} ${bert.family}`, userId: bert.id, earlierReports: 0 }
	]);

	// a team member opens a chat only from an inbox they answer, with somebody it reaches
	expect(
		codeOf(
			(await openTeam(chairPage, { inbox: 'CONSULTANT', committee: GV, p: participant(anna) }))
				.result
		)
	).toBe('FORBIDDEN');
	expect(
		codeOf(
			(await openTeam(chairPage, { inbox: 'CHAIR', committee: GV, p: participant(bert) })).result
		)
	).toBe('CONFLICT');
	expect(
		(await openTeam(chairPage, { inbox: 'CHAIR', committee: GV, p: participant(anna) })).id
	).toBe(chat.annaChairs);
});

test('an inbox files its chats in an archive until the next message', async ({ browser }) => {
	const annaPage = await signedIn(browser, anna.id);
	const bertPage = await signedIn(browser, bert.id);
	const chairPage = await signedIn(browser, chair.id);
	const carePage = await signedIn(browser, care.id);

	const ARCHIVE = `mutation ($chat: ID!, $archived: Boolean!) { setChatArchived(chatId: $chat, archived: $archived) }`;
	const FILED = `query ($chat: ID!) {
		chats(where: { id: { eq: $chat } }) { archived teamArchivedAt unreadCount }
	}`;
	type Filed = { archived: boolean; teamArchivedAt: string | null; unreadCount: number };
	const filed = async (page: Page, id: string) =>
		(await gql<{ chats: Filed[] }>(page, FILED, { chat: id })).data?.chats[0];

	// only whoever answers the inbox files its chats: not the participant, not another inbox, and
	// a chat between participants has no archive
	expect(codeOf(await gql(bertPage, ARCHIVE, { chat: chat.bertCare, archived: true }))).toBe(
		'FORBIDDEN'
	);
	expect(codeOf(await gql(chairPage, ARCHIVE, { chat: chat.bertCare, archived: true }))).toBe(
		'NOT_FOUND'
	);
	expect(codeOf(await gql(annaPage, ARCHIVE, { chat: chat.annaCarla, archived: true }))).toBe(
		'FORBIDDEN'
	);
	expect((await filed(carePage, chat.bertCare))?.archived).toBe(false);

	// participant care puts the chat away, which reads it; the participant is not told
	expect(
		(await gql(carePage, ARCHIVE, { chat: chat.bertCare, archived: true })).errors
	).toBeUndefined();
	const put = await filed(carePage, chat.bertCare);
	expect(put).toMatchObject({ archived: true, unreadCount: 0 });
	expect(put?.teamArchivedAt).not.toBeNull();
	expect(await filed(bertPage, chat.bertCare)).toMatchObject({
		archived: false,
		teamArchivedAt: null
	});

	// it can be taken out again by hand
	await gql(carePage, ARCHIVE, { chat: chat.bertCare, archived: false });
	expect((await filed(carePage, chat.bertCare))?.archived).toBe(false);

	// and the next message brings it back by itself, unread
	await gql(carePage, ARCHIVE, { chat: chat.bertCare, archived: true });
	expect((await send(bertPage, chat.bertCare, 'Noch eine Frage')).errors).toBeUndefined();
	expect(await filed(carePage, chat.bertCare)).toMatchObject({
		archived: false,
		teamArchivedAt: null,
		unreadCount: 1
	});

	for (const page of [annaPage, bertPage, chairPage, carePage]) await page.context().close();
});

test('blocking closes a direct chat for both, and only that chat', async ({ browser }) => {
	const annaPage = await signedIn(browser, anna.id);
	const carlaPage = await signedIn(browser, carla.id);
	const BLOCK = `mutation ($chat: ID!, $blocked: Boolean!) { setChatBlocked(chatId: $chat, blocked: $blocked) }`;

	expect(
		(await gql(carlaPage, BLOCK, { chat: chat.annaCarla, blocked: true })).errors
	).toBeUndefined();
	expect(codeOf(await send(annaPage, chat.annaCarla, 'noch da?'))).toBe('CONFLICT');
	expect(codeOf(await send(carlaPage, chat.annaCarla, 'nein'))).toBe('CONFLICT');
	// the team is still hers to write to
	expect((await send(annaPage, chat.annaChairs, 'Danke!')).errors).toBeUndefined();
	// a team chat has nobody to block
	expect(codeOf(await gql(annaPage, BLOCK, { chat: chat.annaChairs, blocked: true }))).toBe(
		'INVALID_INPUT'
	);

	await gql(carlaPage, BLOCK, { chat: chat.annaCarla, blocked: false });
	expect((await send(annaPage, chat.annaCarla, 'wieder da')).errors).toBeUndefined();
});

test('participant care reads a chat only while it is reported, and may suspend', async ({
	browser
}) => {
	const annaPage = await signedIn(browser, anna.id);
	const carlaPage = await signedIn(browser, carla.id);
	const carePage = await signedIn(browser, care.id);
	const chairPage = await signedIn(browser, chair.id);

	// only a party reports, and only chats between participants
	const REPORT = `mutation ($chat: ID!, $reason: String!) { reportChat(chatId: $chat, reason: $reason) }`;
	expect(codeOf(await gql(carePage, REPORT, { chat: chat.annaCarla, reason: 'x' }))).toBe(
		'NOT_FOUND'
	);
	expect(codeOf(await gql(annaPage, REPORT, { chat: chat.annaChairs, reason: 'x' }))).toBe(
		'INVALID_INPUT'
	);
	expect(
		(await gql(carlaPage, REPORT, { chat: chat.annaCarla, reason: 'Unfreundlich' })).errors
	).toBeUndefined();

	// participant care now reads it, with the names, but does not write; the chair still sees nothing
	const reviewed = (await chatsOf(carePage)).find((row) => row.id === chat.annaCarla);
	expect(reviewed).toMatchObject({ side: 'REVIEW', underReview: true });
	expect(reviewed?.people.map((person) => person.name).sort()).toEqual([
		`${anna.given} ${anna.family}`,
		`${carla.given} ${carla.family}`
	]);
	const read = await messagesOf(carePage, chat.annaCarla);
	expect(read[0]).toMatchObject({ body: 'Hallo Frankreich!', authorName: 'Anna Alpha' });
	expect(codeOf(await send(carePage, chat.annaCarla, 'Hier die Betreuung'))).toBe('FORBIDDEN');
	expect((await chatsOf(chairPage)).map((row) => row.id)).not.toContain(chat.annaCarla);

	const REPORTS = `query ($c: ID!) { chatReports(where: { conferenceId: { eq: $c } }) { id reason status reporterName } }`;
	const reports = await gql<{
		chatReports: { id: string; reason: string; status: string; reporterName: string }[];
	}>(carePage, REPORTS, { c: CONFERENCE });
	expect(reports.data?.chatReports).toEqual([
		expect.objectContaining({ reason: 'Unfreundlich', status: 'OPEN', reporterName: 'Carla Gamma' })
	]);
	// reports are participant care's alone
	for (const page of [annaPage, carlaPage, chairPage]) {
		expect(
			(await gql<{ chatReports: unknown[] }>(page, REPORTS, { c: CONFERENCE })).data?.chatReports
		).toEqual([]);
	}

	// suspending is participant care's; a suspended person still reaches the team
	const SUSPEND = `mutation ($p: ID!, $suspended: Boolean!) { setMessagingSuspended(participantId: $p, suspended: $suspended) }`;
	expect(codeOf(await gql(chairPage, SUSPEND, { p: participant(anna), suspended: true }))).toBe(
		'FORBIDDEN'
	);
	expect(
		(await gql(carePage, SUSPEND, { p: participant(anna), suspended: true })).errors
	).toBeUndefined();
	await expect
		.poll(async () => codeOf(await send(annaPage, chat.annaCarla, 'gesperrt?')))
		.toBe('CONFLICT');
	expect((await send(annaPage, chat.annaChairs, 'Ich bin gesperrt')).errors).toBeUndefined();
	await gql(carePage, SUSPEND, { p: participant(anna), suspended: false });

	// settling the report makes the chat private again
	const RESOLVE = `mutation ($id: ID!) { resolveChatReport(id: $id) { status } }`;
	const reportId = reports.data?.chatReports[0]?.id ?? '';
	expect(codeOf(await gql(chairPage, RESOLVE, { id: reportId }))).toBe('NOT_FOUND');
	expect((await gql(carePage, RESOLVE, { id: reportId })).errors).toBeUndefined();
	expect((await chatsOf(carePage)).map((row) => row.id)).not.toContain(chat.annaCarla);
	expect(await messagesOf(carePage, chat.annaCarla)).toEqual([]);
});

test("a reported delegation group names all its members, and a chat's reports are settled together", async ({
	browser
}) => {
	const annaPage = await signedIn(browser, anna.id);
	const bertPage = await signedIn(browser, bert.id);
	const carlaPage = await signedIn(browser, carla.id);
	const carePage = await signedIn(browser, care.id);
	const chairPage = await signedIn(browser, chair.id);

	const opened = await gql<{ openDelegationChat: { id: string } }>(
		bertPage,
		`mutation ($c: ID!) { openDelegationChat(conferenceId: $c) { id } }`,
		{ c: CONFERENCE }
	);
	const group = opened.data?.openDelegationChat.id ?? '';
	expect((await send(bertPage, group, 'Hallo Delegation')).errors).toBeUndefined();

	// its members know each other: the group lists nobody for them, and nobody else reports it
	expect((await chatsOf(annaPage)).find((row) => row.id === group)).toMatchObject({
		contacts: [],
		people: []
	});
	const REPORT = `mutation ($chat: ID!, $reason: String!) { reportChat(chatId: $chat, reason: $reason) }`;
	expect(codeOf(await gql(carlaPage, REPORT, { chat: group, reason: 'x' }))).toBe('NOT_FOUND');
	await gql(bertPage, REPORT, { chat: group, reason: 'Erste Meldung' });
	await gql(bertPage, REPORT, { chat: group, reason: 'Zweite Meldung' });

	// participant care gets every member, by role and by name
	const reviewed = (await chatsOf(carePage)).find((row) => row.id === group);
	expect(reviewed).toMatchObject({ kind: 'DELEGATION', side: 'REVIEW', underReview: true });
	expect(reviewed?.people.map((person) => person.name).sort()).toEqual([
		`${anna.given} ${anna.family}`,
		`${bert.given} ${bert.family}`
	]);
	expect(reviewed?.contacts.map((contact) => contact.userId).sort()).toEqual(
		[anna.id, bert.id].sort()
	);

	const REPORTS = `query ($chat: ID!) {
		chatReports(where: { chatId: { eq: $chat } }, orderBy: { createdAt: asc }) {
			reason status reporterParticipantId resolutionNote resolvedByName
		}
	}`;
	type Report = {
		reason: string;
		status: string;
		reporterParticipantId: string | null;
		resolutionNote: string | null;
		resolvedByName: string | null;
	};
	const reportsOf = async (page: Page) =>
		(await gql<{ chatReports: Report[] }>(page, REPORTS, { chat: group })).data?.chatReports ?? [];
	expect(await reportsOf(carePage)).toEqual([
		expect.objectContaining({ reason: 'Erste Meldung', reporterParticipantId: participant(bert) }),
		expect.objectContaining({ reason: 'Zweite Meldung', status: 'OPEN', resolutionNote: null })
	]);

	// only participant care settles them, all at once, with a note the team reads
	const SETTLE = `mutation ($chat: ID!, $note: String) { resolveChatReports(chatId: $chat, note: $note) }`;
	for (const page of [chairPage, bertPage]) {
		expect(codeOf(await gql(page, SETTLE, { chat: group }))).toBe('NOT_FOUND');
	}
	expect(codeOf(await gql(carePage, SETTLE, { chat: group, note: 'x'.repeat(2001) }))).toBe(
		'INVALID_INPUT'
	);
	const settled = await gql<{ resolveChatReports: number }>(carePage, SETTLE, {
		chat: group,
		note: ' Mit der Delegation gesprochen. '
	});
	expect(settled.data?.resolveChatReports).toBe(2);
	for (const report of await reportsOf(carePage)) {
		expect(report).toMatchObject({
			status: 'RESOLVED',
			resolutionNote: 'Mit der Delegation gesprochen.',
			resolvedByName: `${care.given} ${care.family}`
		});
	}
	expect(await reportsOf(bertPage)).toEqual([]);
	// the group is private again, and there is nothing left to settle
	expect((await chatsOf(carePage)).map((row) => row.id)).not.toContain(group);
	expect(codeOf(await gql(carePage, SETTLE, { chat: group }))).toBe('NOT_FOUND');

	// a later report shows what there was before about the chats of each person, their own aside:
	// Anna's chat with Carla (settled above) and her delegation's group; Carla filed hers herself
	await gql(carlaPage, REPORT, { chat: chat.annaCarla, reason: 'Schon wieder' });
	const again = (await chatsOf(carePage)).find((row) => row.id === chat.annaCarla);
	const earlier = (person: { id: string }) =>
		again?.people.find((row) => row.userId === person.id)?.earlierReports;
	expect(earlier(anna)).toBe(3);
	expect(earlier(carla)).toBe(0);
	expect((await gql(carePage, SETTLE, { chat: chat.annaCarla })).data).toEqual({
		resolveChatReports: 1
	});
	// five more sessions than the specs before: hand them back
	for (const page of [annaPage, bertPage, carlaPage, carePage, chairPage]) {
		await page.context().close();
	}
});

test('committee functions are handed out by whoever manages the team', async ({ browser }) => {
	const memberPage = await signedIn(browser, member.id);
	const managementPage = await signedIn(browser, management.id);
	const GIVE = `mutation ($member: ID!, $committee: ID!) {
		giveTeamFunction(teamMemberId: $member, committeeId: $committee, kind: CHAIR) { id }
	}`;
	const teamMemberId = `e2e-team-${member.id}`;

	expect(codeOf(await gql(memberPage, GIVE, { member: teamMemberId, committee: SR }))).toBe(
		'FORBIDDEN'
	);
	// a committee of another conference is refused by the database
	expect(
		codeOf(await gql(managementPage, GIVE, { member: teamMemberId, committee: E2E_SEATS_GV_ID }))
	).toBe('INVALID_INPUT');

	const given = await gql<{ giveTeamFunction: { id: string } }>(managementPage, GIVE, {
		member: teamMemberId,
		committee: SR
	});
	expect(given.errors).toBeUndefined();

	// SR is chaired now: Bert, who sits there, reaches its chairs, and the member reads the chat
	const bertPage = await signedIn(browser, bert.id);
	const opened = await openTeam(bertPage, { inbox: 'CHAIR', committee: SR });
	expect(opened.result.errors).toBeUndefined();
	await send(bertPage, opened.id, 'Frage an den neuen Vorsitz');
	expect((await chatsOf(memberPage)).map((row) => row.id)).toEqual([opened.id]);

	const REMOVE = `mutation ($id: ID!) { removeTeamFunction(id: $id) }`;
	const functionId = given.data?.giveTeamFunction.id ?? '';
	expect(codeOf(await gql(memberPage, REMOVE, { id: functionId }))).toBe('NOT_FOUND');
	expect((await gql(managementPage, REMOVE, { id: functionId })).errors).toBeUndefined();
	// without the function the inbox is nobody's any more
	expect(await chatsOf(memberPage)).toEqual([]);
});

test('what is written to the trusted persons stays with them', async ({ browser }) => {
	const doraPage = await signedIn(browser, dora.id);
	const tessaPage = await signedIn(browser, tessa.id);
	const theoPage = await signedIn(browser, theo.id);
	const carePage = await signedIn(browser, care.id);
	const managementPage = await signedIn(browser, management.id);
	const adminPage = await (await browser.newContext()).newPage();
	await loginAs(adminPage, fixedTestUser('e2e-msa-admin', { roles: ['admin'] }));

	// Dora finds the trusted persons together, and each of them by name (never by account)
	const INBOXES = `query ($c: ID!) { chatInboxes(conferenceId: $c) { inbox trustedPersonId personName } }`;
	type Inbox = { inbox: string; trustedPersonId: string | null; personName: string | null };
	const listed = await gql<{ chatInboxes: Inbox[] }>(doraPage, INBOXES, { c: CONFERENCE });
	const trusted = (listed.data?.chatInboxes ?? []).filter((row) => row.inbox === 'TRUSTED_PERSON');
	expect(trusted.map((row) => row.personName)).toEqual([
		null,
		`${tessa.given} ${tessa.family}`,
		`${theo.given} ${theo.family}`
	]);
	const toTessa = trusted[1]?.trustedPersonId ?? '';
	expect(toTessa).not.toBe('');
	expect(JSON.stringify(trusted)).not.toContain(tessa.id);

	const shared = (await openTeam(doraPage, { inbox: 'TRUSTED_PERSON' })).id;
	const personal = (await openTeam(doraPage, { inbox: 'TRUSTED_PERSON', trusted: toTessa })).id;
	expect(shared).not.toBe('');
	expect(personal).not.toBe('');
	expect(personal).not.toBe(shared);
	// asking again finds the same chats
	expect((await openTeam(doraPage, { inbox: 'TRUSTED_PERSON', trusted: toTessa })).id).toBe(
		personal
	);
	await send(doraPage, shared, 'An alle Vertrauenspersonen');
	await send(doraPage, personal, 'Nur für Tessa');

	// both read what was written to all of them; only Tessa what was written to her
	const idsOf = async (page: Page) => (await chatsOf(page)).map((row) => row.id).sort();
	expect(await idsOf(tessaPage)).toEqual([shared, personal].sort());
	expect(await idsOf(theoPage)).toEqual([shared]);
	expect(await messagesOf(theoPage, personal)).toEqual([]);
	expect(codeOf(await send(theoPage, personal, 'mitlesen?'))).toBe('NOT_FOUND');

	// nobody else: not participant care, not project management, not a system admin
	for (const page of [carePage, managementPage, adminPage]) {
		const ids = await idsOf(page);
		expect(ids).not.toContain(shared);
		expect(ids).not.toContain(personal);
		expect(await messagesOf(page, shared)).toEqual([]);
		expect(await messagesOf(page, personal)).toEqual([]);
		expect(codeOf(await send(page, shared, 'mitlesen?'))).toBe('NOT_FOUND');
	}

	// Dora stays a role to them, and their answer carries their name
	const tessasChats = await chatsOf(tessaPage);
	for (const row of tessasChats) {
		expect(row.side).toBe('TEAM');
		expect(row.contacts[0]).toMatchObject({ nationAlpha3Code: 'fra', userId: null });
		expect(row.people).toEqual([]);
	}
	const [question] = await messagesOf(tessaPage, personal);
	expect(question).toMatchObject({ body: 'Nur für Tessa', authorName: null });
	expect((await send(tessaPage, personal, 'Ich bin für dich da')).errors).toBeUndefined();
	const [, answer] = await messagesOf(doraPage, personal);
	expect(answer).toMatchObject({
		fromTeam: true,
		authorName: `${tessa.given} ${tessa.family}`,
		teamAuthorUserId: null
	});

	// such a chat cannot be reported to participant care
	const REPORT = `mutation ($chat: ID!) { reportChat(chatId: $chat, reason: "x") }`;
	expect(codeOf(await gql(doraPage, REPORT, { chat: personal }))).toBe('INVALID_INPUT');

	// a trusted person is one for the whole conference: no committee, and no committee function without one
	const GIVE = `mutation ($member: ID!, $committee: ID, $kind: TeamfunctionkindEnum!) {
		giveTeamFunction(teamMemberId: $member, committeeId: $committee, kind: $kind) { id }
	}`;
	const memberRow = `e2e-team-${member.id}`;
	expect(
		codeOf(
			await gql(managementPage, GIVE, { member: memberRow, committee: GV, kind: 'TRUSTED_PERSON' })
		)
	).toBe('INVALID_INPUT');
	expect(codeOf(await gql(managementPage, GIVE, { member: memberRow, kind: 'CHAIR' }))).toBe(
		'INVALID_INPUT'
	);
	expect(codeOf(await gql(tessaPage, GIVE, { member: memberRow, kind: 'TRUSTED_PERSON' }))).toBe(
		'FORBIDDEN'
	);
});

test('switching messaging off closes the chats between delegations, not the team or the own group', async ({
	browser
}) => {
	const annaPage = await signedIn(browser, anna.id);
	const bertPage = await signedIn(browser, bert.id);
	const chairPage = await signedIn(browser, chair.id);
	const managementPage = await signedIn(browser, management.id);
	const SWITCH = `mutation ($c: ID!, $on: Boolean!) { updateConference(id: $c, messagingEnabled: $on) { messagingEnabled } }`;

	expect(codeOf(await gql(chairPage, SWITCH, { c: CONFERENCE, on: false }))).toBe('FORBIDDEN');
	expect((await gql(managementPage, SWITCH, { c: CONFERENCE, on: false })).errors).toBeUndefined();
	try {
		expect(codeOf(await send(annaPage, chat.annaCarla, 'aus?'))).toBe('CONFLICT');
		expect(codeOf((await openDirect(annaPage, dora)).result)).toBe('CONFLICT');
		expect((await messagesOf(annaPage, chat.annaCarla)).length).toBeGreaterThan(0);
		// the team answers and is written to as before, and a delegation's group stays open
		expect((await send(chairPage, chat.annaChairs, 'trotzdem da')).errors).toBeUndefined();
		expect((await send(bertPage, chat.bertCare, 'noch eine Frage')).errors).toBeUndefined();
		const group = await gql<{ openDelegationChat: { id: string } }>(bertPage, OPEN_GROUP, {
			c: CONFERENCE
		});
		const groupId = group.data?.openDelegationChat.id ?? '';
		expect((await send(bertPage, groupId, 'Gruppe offen')).errors).toBeUndefined();
	} finally {
		await gql(managementPage, SWITCH, { c: CONFERENCE, on: true });
	}
	expect((await send(annaPage, chat.annaCarla, 'wieder an')).errors).toBeUndefined();
});

test("an applicant reaches the team and their group before the release, and a rejected delegation's group closes", async ({
	browser
}) => {
	const emilPage = await signedIn(browser, fixture.applicant.id);
	const carePage = await signedIn(browser, care.id);
	const managementPage = await signedIn(browser, management.id);
	const RELEASE = `mutation ($c: ID!, $on: Boolean!) { setAssignmentReleased(conferenceId: $c, released: $on) }`;
	const SWITCH = `mutation ($c: ID!, $on: Boolean!) { updateConference(id: $c, messagingEnabled: $on) { messagingEnabled } }`;
	const openGroup = async () =>
		gql<{ openDelegationChat: { id: string } }>(emilPage, OPEN_GROUP, { c: CONFERENCE });

	// while the team still selects, with the switch off: the group and the team are open
	expect((await gql(managementPage, RELEASE, { c: CONFERENCE, on: false })).errors).toBeUndefined();
	expect((await gql(managementPage, SWITCH, { c: CONFERENCE, on: false })).errors).toBeUndefined();
	// assigned in the `try`, so the release is put back whatever fails there
	let groupId: string;
	try {
		const opened = await openGroup();
		expect(opened.errors).toBeUndefined();
		groupId = opened.data?.openDelegationChat.id ?? '';
		expect((await send(emilPage, groupId, 'Wir bewerben uns!')).errors).toBeUndefined();

		const inboxes = await gql<{ chatInboxes: { inbox: string }[] }>(
			emilPage,
			`query ($c: ID!) { chatInboxes(conferenceId: $c) { inbox } }`,
			{ c: CONFERENCE }
		);
		// participant care, but no committee's inbox without a seat
		expect(inboxes.data?.chatInboxes.map((row) => row.inbox)).toContain('PARTICIPANT_CARE');
		expect(inboxes.data?.chatInboxes.some((row) => row.inbox === 'CHAIR')).toBe(false);
		const careChat = await openTeam(emilPage, { inbox: 'PARTICIPANT_CARE' });
		expect(careChat.result.errors).toBeUndefined();
		expect((await send(emilPage, careChat.id, 'Wann wird zugeteilt?')).errors).toBeUndefined();
		expect((await send(carePage, careChat.id, 'Bald!')).errors).toBeUndefined();
		// other participants only once the roles are released and the switch is on
		expect(codeOf((await openDirect(emilPage, anna)).result)).toBe('CONFLICT');
	} finally {
		await gql(managementPage, SWITCH, { c: CONFERENCE, on: true });
		await gql(managementPage, RELEASE, { c: CONFERENCE, on: true });
	}

	// released without a role: the group stays readable but closed, the team stays reachable
	expect(codeOf(await send(emilPage, groupId, 'Und jetzt?'))).toBe('CONFLICT');
	expect((await messagesOf(emilPage, groupId)).length).toBe(1);
	const careChat = await openTeam(emilPage, { inbox: 'PARTICIPANT_CARE' });
	expect((await send(emilPage, careChat.id, 'Warteliste?')).errors).toBeUndefined();
});

test('participant care hides messages of a reported chat for everybody, for good', async ({
	browser
}) => {
	const annaPage = await signedIn(browser, anna.id);
	const carlaPage = await signedIn(browser, carla.id);
	const carePage = await signedIn(browser, care.id);
	const chairPage = await signedIn(browser, chair.id);

	const HIDE = `mutation ($id: ID!, $reason: String!) { hideChatMessage(id: $id, reason: $reason) }`;
	const HIDE_ALL = `mutation ($chat: ID!, $p: ID!, $reason: String!) {
		hideChatMessagesOf(chatId: $chat, participantId: $p, reason: $reason)
	}`;
	const WITH_IDS = `query ($chat: ID!) {
		chatMessages(where: { chatId: { eq: $chat } }, orderBy: { createdAt: asc }) {
			id body authorParticipantId hiddenAt hiddenReason hiddenById hiddenByName
		}
	}`;
	type Row = {
		id: string;
		body: string | null;
		authorParticipantId: string | null;
		hiddenAt: string | null;
		hiddenReason: string | null;
		hiddenById: string | null;
		hiddenByName: string | null;
	};
	const rowsOf = async (page: Page) =>
		(await gql<{ chatMessages: Row[] }>(page, WITH_IDS, { chat: chat.annaCarla })).data
			?.chatMessages ?? [];

	expect((await send(annaPage, chat.annaCarla, 'Du bist so ein Idiot')).errors).toBeUndefined();
	expect((await send(carlaPage, chat.annaCarla, 'Selber!')).errors).toBeUndefined();
	const insult = (await rowsOf(annaPage)).find((row) => row.body === 'Du bist so ein Idiot');
	if (!insult) throw new Error('The message was not written');

	// nobody hides in a chat that is not reported: it is private
	expect(codeOf(await gql(carePage, HIDE, { id: insult.id, reason: 'Beleidigung' }))).toBe(
		'NOT_FOUND'
	);

	const REPORT = `mutation ($chat: ID!, $reason: String!) { reportChat(chatId: $chat, reason: $reason) }`;
	expect(
		(await gql(carlaPage, REPORT, { chat: chat.annaCarla, reason: 'Beleidigung' })).errors
	).toBeUndefined();

	// only participant care hides, with a reason; a party, the chair and an empty reason are refused
	expect(codeOf(await gql(carlaPage, HIDE, { id: insult.id, reason: 'weg damit' }))).toBe(
		'NOT_FOUND'
	);
	expect(codeOf(await gql(chairPage, HIDE, { id: insult.id, reason: 'weg damit' }))).toBe(
		'NOT_FOUND'
	);
	expect(codeOf(await gql(carePage, HIDE, { id: insult.id, reason: '  ' }))).toBe('INVALID_INPUT');
	expect(
		(await gql(carePage, HIDE, { id: insult.id, reason: 'Beleidigung' })).errors
	).toBeUndefined();
	// final: hiding again is refused, the reason stays
	expect(codeOf(await gql(carePage, HIDE, { id: insult.id, reason: 'anders' }))).toBe('CONFLICT');

	// the parties, the author included, learn that it was hidden, not what it said, who hid it or why
	for (const page of [annaPage, carlaPage]) {
		const hidden = (await rowsOf(page)).find((row) => row.id === insult.id);
		expect(hidden).toMatchObject({
			body: null,
			hiddenReason: null,
			hiddenById: null,
			hiddenByName: null
		});
		expect(hidden?.hiddenAt).not.toBeNull();
		// nor by filtering or searching for the text
		const BY_TEXT = `query ($chat: ID!) {
			a: chatMessages(where: { chatId: { eq: $chat }, body: { ilike: "%Idiot%" } }) { id }
			b: chatMessages(where: { chatId: { eq: $chat } }, search: { term: "Idiot" }) { id }
			c: chatMessages(where: { chatId: { eq: $chat }, hiddenReason: { isNotNull: true } }) { id }
		}`;
		const found = await gql<{ a: unknown[]; b: unknown[]; c: unknown[] }>(page, BY_TEXT, {
			chat: chat.annaCarla
		});
		expect(found.data).toEqual({ a: [], b: [], c: [] });
	}
	const preview = await gql<{ chats: { lastMessagePreview: string | null }[] }>(
		carlaPage,
		`query ($c: ID!) { chats(where: { id: { eq: $c } }) { lastMessagePreview } }`,
		{ c: chat.annaCarla }
	);
	expect(JSON.stringify(preview.data)).not.toContain('Idiot');

	// participant care keeps reading it, with who hid it and why
	expect((await rowsOf(carePage)).find((row) => row.id === insult.id)).toMatchObject({
		body: 'Du bist so ein Idiot',
		hiddenReason: 'Beleidigung',
		hiddenByName: `${care.given} ${care.family}`
	});

	// everything a person wrote so far, and only that: what follows stays visible
	const all = await gql<{ hideChatMessagesOf: number }>(carePage, HIDE_ALL, {
		chat: chat.annaCarla,
		p: participant(carla),
		reason: 'Zurückbeleidigt'
	});
	expect(all.data?.hideChatMessagesOf).toBeGreaterThan(0);
	const carlas = (await rowsOf(annaPage)).filter(
		(row) => row.authorParticipantId === participant(carla)
	);
	expect(carlas.every((row) => row.body === null && row.hiddenAt !== null)).toBe(true);

	// once settled the chat is private again; the report keeps what was hidden under it
	const SETTLE = `mutation ($chat: ID!) { resolveChatReports(chatId: $chat) }`;
	expect((await gql(carePage, SETTLE, { chat: chat.annaCarla })).errors).toBeUndefined();
	expect(await messagesOf(carePage, chat.annaCarla)).toEqual([]);
	const REPORTS = `query ($c: ID!) {
		chatReports(where: { conferenceId: { eq: $c } }, orderBy: { createdAt: desc }) {
			reason hiddenMessages { body authorName hiddenReason hiddenByName }
		}
	}`;
	const history = await gql<{
		chatReports: { reason: string; hiddenMessages: { body: string; hiddenReason: string }[] }[];
	}>(carePage, REPORTS, { c: CONFERENCE });
	const record = history.data?.chatReports.find((report) => report.reason === 'Beleidigung');
	expect(record?.hiddenMessages).toEqual(
		expect.arrayContaining([
			expect.objectContaining({ body: 'Du bist so ein Idiot', hiddenReason: 'Beleidigung' }),
			expect.objectContaining({ body: 'Selber!', hiddenReason: 'Zurückbeleidigt' })
		])
	);
	// and stays participant care's
	expect(
		(await gql<{ chatReports: unknown[] }>(annaPage, REPORTS, { c: CONFERENCE })).data?.chatReports
	).toEqual([]);

	// a new message after the hiding reads as written
	expect((await send(carlaPage, chat.annaCarla, 'Entschuldigung')).errors).toBeUndefined();
	expect((await messagesOf(annaPage, chat.annaCarla)).at(-1)?.body).toBe('Entschuldigung');
});
