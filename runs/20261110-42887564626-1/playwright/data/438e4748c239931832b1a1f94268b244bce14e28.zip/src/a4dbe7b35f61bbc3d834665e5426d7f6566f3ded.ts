import { expect, type Cookie, type Page } from '@playwright/test';

/** The prefix of the cookies the OIDC library keeps the session in (`makeCookieNames`). */
const SESSION_COOKIE = 'auth_oidc_';

/**
 * Claims the oidc-mock login page (oidc-mock.yaml, served by `vite dev`) signs into the tokens,
 * normalized by src/api/services/oidc/OIDC.ts into an OIDCUser.
 */
export interface TestUserClaims {
	email: string;
	given_name: string;
	family_name: string;
	preferred_username: string;
	locale?: string;
	roles?: string[];
	[key: string]: unknown;
}

let counter = 0;

/**
 * Claims for a user old enough to supervise (forty this year), which signing up as a supervisor
 * attending in person takes: `completeMandatoryProfile` enters it as the birthday.
 */
export const SUPERVISOR_AGE = { birthdate: `${new Date().getFullYear() - 40}-05-05` };

/**
 * Builds a unique set of OIDC claims for a fresh test user. Uniqueness matters because
 * the app upserts a User row keyed by the token's `sub`/email on first login - reusing
 * claims across tests would make them share (and race on) the same account.
 */
export function makeTestUser(
	prefix: string,
	overrides: Partial<TestUserClaims> = {}
): TestUserClaims {
	const unique = `e2e-${prefix}-${Date.now()}-${counter++}`;
	return {
		email: `${unique}@e2e.test`,
		given_name: 'Testperson',
		family_name: prefix,
		preferred_username: unique,
		locale: 'de',
		...overrides
	};
}

/**
 * The id as a name the `PersonName` scalar accepts, which allows no digits: each digit becomes a
 * letter, so ids that differ only in a digit (`…-member-1`, `…-member-2`) keep distinct names.
 */
function asPersonName(id: string): string {
	return id.replace(/\d/g, (digit) => String.fromCharCode(65 + Number(digit)));
}

/**
 * Claims for a user with a fixed, predictable id - use this (instead of `makeTestUser`) whenever
 * a test needs the DB fixtures (TeamMember, DelegationMember, ...) seeded ahead of time in
 * e2e/seed/seed.ts, since those rows are created against a fixed userId that must match this
 * user's OIDC `sub`. `loginAs` signs in with `preferred_username` as the token's `sub`, so `id`
 * must be exactly the id used when seeding.
 */
export function fixedTestUser(id: string, overrides: Partial<TestUserClaims> = {}): TestUserClaims {
	return {
		email: `${id}@e2e.test`,
		given_name: 'Testperson',
		family_name: asPersonName(id),
		preferred_username: id,
		locale: 'de',
		...overrides
	};
}

/**
 * Path the oidc-mock provider lives under (`base_path` in oidc-mock.yaml), derived from the same
 * env var the app uses. Its Vite plugin serves the login page on the app's own origin and
 * rewrites the app's redirects to it into relative ones, so the provider is recognised by path,
 * not by origin.
 */
const OIDC_BASE_PATH = new URL(
	(
		process.env.PUBLIC_OIDC_AUTHORITY ??
		'http://127.0.0.1:8090/oidc/.well-known/openid-configuration'
	).replace(/\/\.well-known\/openid-configuration$/, '')
).pathname;

/** True while `url` is on the mock OIDC provider rather than the app under test. */
function isOidcUrl(url: string | URL): boolean {
	try {
		const { pathname } = new URL(url.toString());
		return pathname === OIDC_BASE_PATH || pathname.startsWith(`${OIDC_BASE_PATH}/`);
	} catch {
		return false;
	}
}

/**
 * The session cookies of every sign in this worker made, by the claims it signed in with. Signing
 * in through the provider takes several page loads; the fixed users sign in dozens of times a run.
 */
const sessions = new Map<string, Cookie[]>();

/**
 * Signs in on the oidc-mock login page as `claims`, then - for a brand new user - completes the
 * mandatory "additional info" profile form the app requires before granting access to the rest
 * of the app. Ends with `page` navigated to `startUrl` (or wherever the app redirected to).
 *
 * A user this worker signed in before with the same claims gets that session back instead, and
 * goes through the provider again only if the app no longer accepts it.
 */
export async function loginAs(
	page: Page,
	claims: TestUserClaims,
	opts: { startUrl?: string } = {}
): Promise<void> {
	// Through `/login`: a conference's dashboard and seat overview are public and never send a
	// visitor to the provider on their own. With a valid session it redirects straight to `next`.
	const startUrl = opts.startUrl ?? '/dashboard';
	const sessionKey = JSON.stringify(claims);
	const session = sessions.get(sessionKey);
	// Whoever the page was signed in as before would otherwise pass `/login` straight through
	await page.context().clearCookies();
	if (session) await page.context().addCookies(session);
	await page.goto(`/login?next=${encodeURIComponent(startUrl)}`);
	if (session && !isOidcUrl(page.url())) {
		await waitForHydration(page);
		return;
	}

	await page.waitForURL((url) => isOidcUrl(url), { timeout: 15_000 });
	// The page's "custom claims" form: any `sub`, any claims. Its per-user buttons are for the
	// fixed accounts in oidc-mock.yaml, which the suite does not use. The form sits in a collapsed
	// <details>, so it is opened first.
	await page.getByText('Sign in with custom claims').click();
	await page.locator('#custom_sub').fill(claims.preferred_username);
	await page.locator('#custom_claims').fill(JSON.stringify(claims));
	await page.locator('button[name="custom"]').click();

	await page.waitForURL((url) => !isOidcUrl(url), { timeout: 15_000 });

	if (new URL(page.url()).pathname.startsWith('/my-account')) {
		await completeMandatoryProfile(page, claims);
	}
	sessions.set(
		sessionKey,
		(await page.context().cookies()).filter((cookie) => cookie.name.startsWith(SESSION_COOKIE))
	);

	// A returning fixed-actor user (see `fixedTestUser`) skips the /my-account detour entirely,
	// landing straight on `startUrl` - which otherwise conveniently gives the page's JS bundle a
	// few extra round trips to finish hydrating before a test's first real interaction. Without
	// that buffer, an interaction fired immediately after this function returns can race
	// SvelteKit's hydration (the click/input fires before the handler is attached and is lost).
	await waitForHydration(page);
}

/**
 * `page.reload()` (or any fresh navigation) followed immediately by an interaction is prone to
 * the same hydration race as a fresh `loginAs` login (see the hydration wait there) - the
 * click/input can fire before Svelte's handler is attached. Use this after any `page.reload()`
 * a test does mid-flow, right before the next interaction.
 */
export async function waitForHydration(page: Page): Promise<void> {
	// The root layout sets this in `onMount`. Not `networkidle`: the subscription stream stays open
	// for as long as the page shows live data, so the network never goes idle on most pages.
	await page.waitForFunction(() => document.body.dataset.hydrated === 'true', undefined, {
		timeout: 15_000
	});
}

/**
 * Fills the profile fields the app requires (see `#lib/schemata/userForm`), then saves.
 */
async function completeMandatoryProfile(page: Page, claims: TestUserClaims): Promise<void> {
	// Input fired before hydration attaches the handlers is lost.
	await waitForHydration(page);
	// The legal name comes from `claims` (not a fixed literal) so tests that need to tell users
	// apart by name (e.g. multiple delegation members in one table) still can - see
	// delegation-member-management.spec.ts. Every field is overwritten, since a pre-seeded user
	// (fixedTestUser fixtures) can already hold an invalid value.
	await page.locator('input[name="given_name"]').fill(claims.given_name);
	await page.locator('input[name="family_name"]').fill(claims.family_name);
	await page.locator('input[name="phone"]').fill('+4917612345678');
	await page.locator('input[name="street"]').fill('Teststraße 1');
	await page.locator('input[name="zip"]').fill('24103');
	await page.locator('input[name="city"]').fill('Kiel');
	await page.locator('select[name="country"]').selectOption('DEU');
	await page
		.locator('textarea[name="emergencyContacts"]')
		.fill('Emergency contact: +49 176 12345678');
	// Seventeen this year unless the claims name another (`birthdate`, see `SUPERVISOR_AGE`):
	// inside every conference's default range for participants, which an application has to fit
	// to be sent (`applicationBlockers`), whenever the suite runs.
	const birthday =
		typeof claims.birthdate === 'string'
			? claims.birthdate
			: `${new Date().getFullYear() - 17}-05-05`;
	await page.locator('input[name="birthday"]').fill(birthday);
	await page.locator('select[name="foodPreference"]').selectOption('VEGAN');
	// formsnap generates a random `id` per field (`useId()`), so fields are selected by `name`.
	await page.locator('select[name="gender"]').selectOption('NO_STATEMENT');

	const beforePath = new URL(page.url()).pathname;
	const saveButton = page.locator('.card-body form button.btn-primary').first();
	await expect(saveButton).toBeEnabled({ timeout: 5_000 });
	await saveButton.click();
	await page.waitForURL((url) => new URL(url).pathname !== beforePath, { timeout: 15_000 });
}
