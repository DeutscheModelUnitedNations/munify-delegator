import { test, expect, acceptDialogs } from '../support/test';
import { loginAs, makeTestUser, waitForHydration } from '../support/auth';
import {
	chooseApplyPath,
	fillApplicationSteps,
	openFirstConferenceForRegistration
} from '../support/registration';

// Covers the delegation dashboard's member-management tools (rotating the entry code,
// transferring head delegate, removing a member) - all self-service, all only available before
// the delegation has applied, and none of it is exercised by the create/join-only registration
// tests.
test('a head delegate can rotate the entry code, remove a member, and transfer head delegate', async ({
	browser
}) => {
	// Three separate sign-ups (head delegate plus two members), each through the full login and
	// profile flow, take longer than the default 30s on their own.
	test.setTimeout(90_000);

	const headContext = await browser.newContext();
	const headPage = await headContext.newPage();
	await acceptDialogs(headPage);

	const headDelegate = makeTestUser('member-mgmt-head');
	await loginAs(headPage, headDelegate);
	const conferenceId = await openFirstConferenceForRegistration(headPage);

	await chooseApplyPath(headPage, /Delegation erstellen/);

	const schoolInput = headPage.locator('input[name="schoolName"]');
	await expect(async () => {
		await headPage.getByRole('button', { name: /weiter|next/i }).click();
		await expect(schoolInput).toBeVisible({ timeout: 2_000 });
	}).toPass({ timeout: 15_000 });

	await fillApplicationSteps(headPage, {
		school: 'E2E Test School',
		motivation: 'We want to join.',
		experience: 'Some experience.'
	});

	const entryCodeLocator = headPage.locator('p.font-mono');
	await expect(entryCodeLocator).toBeVisible({ timeout: 15_000 });
	const originalEntryCode = (await entryCodeLocator.textContent())?.trim();

	async function graphql(query: string) {
		const res = await headPage.request.post('/api/graphql', { data: { query } });
		return (await res.json())?.data;
	}

	// --- two members join ---
	async function joinAs(prefix: string, code: string) {
		const context = await browser.newContext();
		const page = await context.newPage();
		const user = makeTestUser(prefix);
		await loginAs(page, user, { startUrl: `/registration/${conferenceId}/join-delegation` });
		await page.locator('input[placeholder="Code"]').fill(code);
		const confirmButton = page.getByRole('button', { name: /bestätigen|confirm/i });
		await expect(confirmButton).toBeVisible({ timeout: 15_000 });
		await confirmButton.click();
		await page.waitForURL(new RegExp(`/dashboard/${conferenceId}$`), { timeout: 15_000 });
		await context.close();
		return user;
	}

	const memberB = await joinAs('member-mgmt-b', originalEntryCode!);
	const memberC = await joinAs('member-mgmt-c', originalEntryCode!);

	await headPage.reload();
	await waitForHydration(headPage);

	// The OIDC subject is the user id, and the mock provider issues `preferred_username` as the
	// subject.
	const memberBUserId = memberB.preferred_username;
	const memberCUserId = memberC.preferred_username;

	// --- rotate the entry code ---
	const dashboardEntryCode = headPage.locator('p.font-mono');
	await expect(dashboardEntryCode).toHaveText(originalEntryCode!, { timeout: 15_000 });
	await headPage.getByRole('button', { name: /code erneuern|rotate code/i }).click();
	await expect(dashboardEntryCode).not.toHaveText(originalEntryCode!, { timeout: 15_000 });

	// --- remove member C ---
	const memberCRow = headPage.locator('tr', { hasText: /member-mgmt-c/i });
	await expect(memberCRow).toBeVisible({ timeout: 15_000 });
	await memberCRow.locator('button.btn-error').click();
	await expect(memberCRow).toBeHidden({ timeout: 15_000 });
	// let the removal's invalidateAll-triggered refetch/re-render fully settle before the next
	// confirm()-gated action - otherwise the next click can land mid-rerender.
	await waitForHydration(headPage);

	const memberCData = await graphql(
		`query { delegationMembers(where: { conference: { id: { eq: "${conferenceId}" } }, user: { id: { eq: "${memberCUserId}" } } }) { id } }`
	);
	expect(memberCData?.delegationMembers).toEqual([]);

	// --- transfer head delegate to member B ---
	const memberBRow = headPage.locator('tr', { hasText: /member-mgmt-b/i });

	async function isMemberBHeadDelegate() {
		const data = await graphql(
			`query { delegationMembers(where: { conference: { id: { eq: "${conferenceId}" } }, user: { id: { eq: "${memberBUserId}" } } }) { isHeadDelegate } }`
		);
		return data?.delegationMembers?.[0]?.isHeadDelegate;
	}

	// Retry the click: this confirm()-gated action has been observed to occasionally not
	// register (the click/dialog gets lost, e.g. if it lands while the previous mutation's
	// invalidateAll re-render is still settling), leaving the button frozen mid-request.
	await expect(async () => {
		await memberBRow.locator('button.btn-warning').click();
		// The confirm dialog is accepted by the `acceptDialogs` handler, which Playwright only runs
		// before a page action or assertion - a GraphQL poll alone would leave it open.
		await expect(headPage.getByRole('alertdialog')).toBeHidden({ timeout: 5_000 });
		await expect.poll(isMemberBHeadDelegate, { timeout: 5_000 }).toBe(true);
	}).toPass({ timeout: 20_000 });
});
