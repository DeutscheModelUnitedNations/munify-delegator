import { test, expect } from '../support/test';
import { loginAs, makeTestUser } from '../support/auth';
import {
	chooseApplyPath,
	fillApplicationSteps,
	openFirstConferenceForRegistration
} from '../support/registration';

test('a head delegate can create a delegation and a second user can join it with the entry code', async ({
	browser
}) => {
	// Two separate sign-ups, each through the full login and profile flow, like the delegation
	// signup spec
	test.setTimeout(90_000);

	const headDelegateContext = await browser.newContext();
	const headDelegatePage = await headDelegateContext.newPage();

	const headDelegate = makeTestUser('head-delegate');
	await loginAs(headDelegatePage, headDelegate);

	const conferenceId = await openFirstConferenceForRegistration(headDelegatePage);

	await chooseApplyPath(headDelegatePage, /Delegation erstellen/);

	// step 0: informational step. Retry the click: a click just after client-side navigation
	// can land before hydration attaches the handler.
	const schoolInput = headDelegatePage.locator('input[name="schoolName"]');
	await expect(async () => {
		await headDelegatePage.getByRole('button', { name: /weiter|next/i }).click();
		await expect(schoolInput).toBeVisible({ timeout: 2_000 });
	}).toPass({ timeout: 15_000 });

	// step 1: questionnaire
	await fillApplicationSteps(headDelegatePage, {
		school: 'E2E Test School',
		motivation: 'We want to join.',
		experience: 'Some experience.'
	});

	// step 2: entry code is shown
	const entryCodeLocator = headDelegatePage.locator('p.font-mono');
	await expect(entryCodeLocator).toBeVisible({ timeout: 15_000 });
	const entryCode = (await entryCodeLocator.textContent())?.trim();
	expect(entryCode).toBeTruthy();

	await headDelegateContext.close();

	// --- second user joins the delegation using the entry code ---
	const memberContext = await browser.newContext();
	const memberPage = await memberContext.newPage();

	const member = makeTestUser('delegation-member');
	await loginAs(memberPage, member, {
		startUrl: `/registration/${conferenceId}/join-delegation`
	});

	if (!memberPage.url().includes('/join-delegation')) {
		await memberPage.goto(`/registration/${conferenceId}/join-delegation`);
	}

	await memberPage.locator('input[placeholder="Code"]').fill(entryCode!);
	await expect(memberPage.getByRole('button', { name: /bestätigen|confirm/i })).toBeVisible({
		timeout: 15_000
	});
	// the newcomer's own school starts as the head delegate's
	await expect(memberPage.locator('input[name="schoolName"]')).toHaveValue('E2E Test School');
	await memberPage.getByRole('button', { name: /bestätigen|confirm/i }).click();

	await memberPage.waitForURL(new RegExp(`/dashboard/${conferenceId}$`));
	await expect(memberPage).toHaveURL(new RegExp(`/dashboard/${conferenceId}$`));

	// ...and is kept as their own: the delegation has none
	const res = await memberPage.request.post('/api/graphql', {
		data: {
			query: `query { conferenceParticipants(where: { conferenceId: { eq: "${conferenceId}" }, userId: { eq: "${member.preferred_username}" } }) { school { name } } }`
		}
	});
	const participant = (await res.json())?.data?.conferenceParticipants?.[0];
	expect(participant?.school?.name).toBe('E2E Test School');

	await memberContext.close();
});
