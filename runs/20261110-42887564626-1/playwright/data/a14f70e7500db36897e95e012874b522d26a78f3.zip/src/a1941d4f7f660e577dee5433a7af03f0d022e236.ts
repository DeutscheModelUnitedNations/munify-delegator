import { test, expect, acceptDialogs } from '../support/test';
import { loginAs, makeTestUser, waitForHydration } from '../support/auth';
import {
	chooseApplyPath,
	fillApplicationSteps,
	openFirstConferenceForRegistration
} from '../support/registration';

// Covers the head delegate's "delegation payment" variant - a reference covering the whole
// delegation, distinct participant-selection logic from the "single" variant already covered in
// payment.spec.ts.
test('a head delegate can generate a delegation payment reference covering all members', async ({
	browser
}) => {
	// Two separate sign-ups, each through the full login and profile flow, plus the flow itself
	// run within a few seconds of the default 30s.
	test.setTimeout(90_000);

	const headContext = await browser.newContext();
	const headPage = await headContext.newPage();
	await acceptDialogs(headPage);

	const headDelegate = makeTestUser('payment-deleg-head');
	await loginAs(headPage, headDelegate);
	const conferenceId = await openFirstConferenceForRegistration(headPage);

	await chooseApplyPath(headPage, /Delegation erstellen/);

	const schoolInput = headPage.locator('input[name="schoolName"]');
	await expect(async () => {
		await headPage.getByRole('button', { name: /weiter|next/i }).click();
		await expect(schoolInput).toBeVisible({ timeout: 2_000 });
	}).toPass({ timeout: 15_000 });

	await fillApplicationSteps(headPage, {
		school: 'E2E Test School',
		motivation: 'We want to join.',
		experience: 'Some experience.'
	});

	const entryCodeLocator = headPage.locator('p.font-mono');
	await expect(entryCodeLocator).toBeVisible({ timeout: 15_000 });
	const entryCode = (await entryCodeLocator.textContent())?.trim();

	// --- a second member joins ---
	const memberContext = await browser.newContext();
	const memberPage = await memberContext.newPage();
	const member = makeTestUser('payment-deleg-member');
	await loginAs(memberPage, member, {
		startUrl: `/registration/${conferenceId}/join-delegation`
	});
	await memberPage.locator('input[placeholder="Code"]').fill(entryCode!);
	const confirmButton = memberPage.getByRole('button', { name: /bestätigen|confirm/i });
	await expect(confirmButton).toBeVisible({ timeout: 15_000 });
	await confirmButton.click();
	await memberPage.waitForURL(new RegExp(`/dashboard/${conferenceId}$`), { timeout: 15_000 });
	await memberContext.close();

	const feeRes = await headPage.request.post('/api/graphql', {
		data: {
			query: `query { conference(id: "${conferenceId}") { feeAmount } }`
		}
	});
	const feeAmount = (await feeRes.json())?.data?.conference?.feeAmount as number;
	expect(feeAmount).toBeGreaterThan(0);

	await headPage.goto(`/dashboard/${conferenceId}/payment`);
	await waitForHydration(headPage);
	await headPage.getByLabel(/für andere mitbezahlen|pay for others too/i).check();

	const generateButton = headPage.locator('button:has(.ph-sparkle)');
	await expect(generateButton).toBeEnabled({ timeout: 15_000 });
	await generateButton.click();

	const readonlyInputs = headPage.locator('input[readonly]');
	await expect(readonlyInputs.last()).toHaveValue(/.+/, { timeout: 15_000 });
	const amountText = await readonlyInputs.nth(4).inputValue();
	expect(parseFloat(amountText)).toBeCloseTo(feeAmount * 2, 1);
});
